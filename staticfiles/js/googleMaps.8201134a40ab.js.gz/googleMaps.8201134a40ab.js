$( document ).ready(function() {
    
    // // alert( "ready!" );
    // var $demo = $("#demo")
    // function getLocation() {
    //     // console.log("location....");
    //       if (navigator.geolocation) {
    //         // console.log('getting this...');
    //           navigator.geolocation.getCurrentPosition(showPosition);
    //       } else {
    //           $demo.html("Geolocation is not supported by this browser.");
    //       }
    //   }
    // function showPosition(position) {
    //     // console.log("postion.....");
    //     var latitude = position.coords.latitude;
    //     var latitude = position.coords.longitude;
    //     $demo.html("Latitude: " + position.coords.latitude + 
    //         "<br>Longitude: " + position.coords.longitude); 
    //     // initMap(position.coords.latitude, position.coords.longitude )

    // }



    // // function initMap(latitude, longitude) {
    // //     console.log("get this?");
    // //     var url = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAso1CPfl8yBx56oJI7wVUE0yJL3o_bx0k"
    // //     var uluru = {lat: latitude, lng: longitude};
    // //     var map = new google.maps.Map($("#map"), {
    // //       zoom: 15,
    // //       center: uluru
    // //     });
    // //     var marker = new google.maps.Marker({
    // //       position: uluru,
    // //       map: map
    // //     });
    // // }

    // getLocation();
});
